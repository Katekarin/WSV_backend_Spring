@NonNullByDefault
package pl.wsb.fitnesstracker.mail.internal;

import org.eclipse.jdt.annotation.NonNullByDefault;